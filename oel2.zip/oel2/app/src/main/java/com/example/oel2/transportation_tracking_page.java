package com.example.oel2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class transportation_tracking_page extends AppCompatActivity {

    private TextView mRouteTextView;
    private TextView mStatusTextView;
    private TextView mDelayTextView;
    private TextView mCancellationTextView;
    private Button mRefreshButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transportation_tracking_page);

        // Get references to UI elements
        mRouteTextView = findViewById(R.id.route_textview);
        mStatusTextView = findViewById(R.id.status_textview);
        mDelayTextView = findViewById(R.id.delay_textview);
        mCancellationTextView = findViewById(R.id.cancellation_textview);
        mRefreshButton = findViewById(R.id.refresh_button);

        // Set click listener for refresh button
        mRefreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Refresh transportation information
                updateTransportationInfo("Route A", "On time", "No delays", "No cancellations");
            }
        });

        // TODO: Load transportation information from backend server or API
        updateTransportationInfo("Route A", "On time", "No delays", "No cancellations");
    }

    private void updateTransportationInfo(String route, String status, String delay, String cancellation) {
        // Update UI elements with new transportation information
        mRouteTextView.setText(route);
        mStatusTextView.setText(status);
        mDelayTextView.setText(delay);
        mCancellationTextView.setText(cancellation);
    }
}