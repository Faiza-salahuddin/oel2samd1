package com.example.oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;


public class trip_planning extends AppCompatActivity {

    private EditText fromEditText, toEditText;
    private CheckBox carCheckBox, busCheckBox, trainCheckBox;
    private Button searchButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fromEditText = findViewById(R.id.from_edit_text);
        toEditText = findViewById(R.id.to_edit_text);
        carCheckBox = findViewById(R.id.car_checkbox);
        busCheckBox = findViewById(R.id.bus_checkbox);
        trainCheckBox = findViewById(R.id.train_checkbox);
        searchButton = findViewById(R.id.search_button);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to handle search button click
            }
        });
    }
}