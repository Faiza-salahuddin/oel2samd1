package com.example.oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Cost_saving_features extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cost_saving_features);

        // Add onClickListener for find carpool button
        Button findCarpoolButton = findViewById(R.id.find_carpool_button);
        findCarpoolButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch carpool matching activity
                Intent intent = new Intent(Cost_saving_features.this,
                        transportation_tracking_page.class);
                startActivity(intent);
            }
        });

        // Add onClickListener for purchase pass button
        Button purchasePassButton = findViewById(R.id.purchase_pass_button);
        purchasePassButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch transit pass purchase activity
                Intent intent = new Intent(Cost_saving_features.this,
                        trip_planning.class);
                startActivity(intent);
            }
        });
    }
}