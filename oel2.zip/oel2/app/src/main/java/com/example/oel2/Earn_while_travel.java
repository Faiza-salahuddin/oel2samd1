package com.example.oel2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
public class Earn_while_travel extends AppCompatActivity {

    private EditText startLocationEditText;
    private EditText endLocationEditText;
    private EditText dateEditText;
    private EditText timeEditText;
    private EditText priceEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earn_while_travel);

        startLocationEditText = findViewById(R.id.start_location_edittext);
        endLocationEditText = findViewById(R.id.end_location_edittext);
        dateEditText = findViewById(R.id.date_edittext);
        timeEditText = findViewById(R.id.time_edittext);
        priceEditText = findViewById(R.id.price_edittext);
        submitButton = findViewById(R.id.submit_button);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the values from the EditText views
                String startLocation = startLocationEditText.getText().toString();
                String endLocation = endLocationEditText.getText().toString();
                String date = dateEditText.getText().toString();
                String time = timeEditText.getText().toString();
                String price = priceEditText.getText().toString();

                Intent intent = new Intent(Earn_while_travel.this,trip_planning.class);
                startActivity(intent);
            }
        });
    }
}