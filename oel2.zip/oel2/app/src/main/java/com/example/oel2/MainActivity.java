package com.example.oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
public class MainActivity extends AppCompatActivity {

    private EditText mEmailEditText;
    private EditText mPasswordEditText;
    private RadioGroup mUserTypeRadioGroup;
    private RadioButton mSimpleUserRadioButton;
    private RadioButton mVehicleOwnerRadioButton;
    private Button mLoginButton;
    private Button mSignupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEmailEditText = findViewById(R.id.email_edit_text);
        mPasswordEditText = findViewById(R.id.password_edit_text);
        mUserTypeRadioGroup = findViewById(R.id.user_type_radio_group);
        mSimpleUserRadioButton = findViewById(R.id.simple_user_radio_button);
        mVehicleOwnerRadioButton = findViewById(R.id.vehicle_owner_radio_button);
        mLoginButton = findViewById(R.id.login_button);
        mSignupButton = findViewById(R.id.signup_button);

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        mSignupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,trip_planning.class);
                startActivity(intent);
            }
        });
    }
}







